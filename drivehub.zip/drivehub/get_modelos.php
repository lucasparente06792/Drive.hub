<?php
include 'config/db.php';

$marca = isset($_GET['marca']) ? $conn->real_escape_string($_GET['marca']) : '';
$modelo = isset($_GET['modelo']) ? $conn->real_escape_string($_GET['modelo']) : '';
$tipo = isset($_GET['tipo']) ? $_GET['tipo'] : '';

// Base da query: filtrar sempre pela marca (e modelo se existir)
$where = "WHERE 1=1";
if ($marca) $where .= " AND marca = '$marca'";
if ($modelo) $where .= " AND modelo = '$modelo'";

if ($tipo == 'modelo') {
    echo '<option value="">Todos os Modelos</option>';
    $sql = "SELECT modelo, COUNT(*) as total FROM veiculos $where GROUP BY modelo ORDER BY modelo ASC";
} 
elseif ($tipo == 'ano') {
    echo '<option value="">Todos</option>';
    $sql = "SELECT ano, COUNT(*) as total FROM veiculos $where GROUP BY ano ORDER BY ano DESC";
} 
elseif ($tipo == 'combustivel') {
    echo '<option value="">Todos</option>';
    $sql = "SELECT combustivel, COUNT(*) as total FROM veiculos $where GROUP BY combustivel ORDER BY combustivel ASC";
}

$res = $conn->query($sql);
while ($row = $res->fetch_assoc()) {
    $nome = $row[$tipo];
    if(empty($nome)) continue;
    echo "<option value='$nome'>$nome ({$row['total']})</option>";
}