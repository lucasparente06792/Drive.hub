<?php 
include 'config/db.php'; 
include 'includes/header.php'; 

if(isset($_GET['id'])) {
    $id_veiculo = $_GET['id'];
    $sql = "SELECT * FROM veiculos WHERE id = $id_veiculo";
    $result = $conn->query($sql);
    
    if($result->num_rows > 0) {
        $carro = $result->fetch_assoc();
    } else {
        echo "<div class='container mt-5'><div class='alert alert-danger'>Carro não encontrado.</div></div>";
        include 'includes/footer.php'; exit;
    }
} else {
    echo "<div class='container mt-5'><div class='alert alert-danger'>ID não fornecido.</div></div>";
    include 'includes/footer.php'; exit;
}
?>

<div class="container mt-5">
    <a href="index.php" class="btn btn-outline-secondary mb-4">&larr; Voltar ao Stock</a>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <?php $imagem = !empty($carro["foto_capa"]) ? $carro["foto_capa"] : "https://placehold.co/600x400?text=Sem+Foto"; ?>
                <img src="<?php echo $imagem; ?>" class="card-img-top detail-page-image" alt="Foto do carro">
                
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h2 class="card-title text-primary mb-0"><?php echo $carro['marca'] . ' ' . $carro['modelo']; ?></h2>
                            <h5 class="text-muted"><?php echo $carro['versao']; ?></h5>
                        </div>
                        <span class="badge bg-secondary fs-6"><?php echo $carro['estado']; ?></span>
                    </div>

                    <div class="row text-center mb-4">
                        <div class="col-3 border-end">
                            <i class="bi bi-calendar fs-3 text-primary"></i>
                            <p class="mb-0 fw-bold"><?php echo $carro['ano']; ?></p>
                            <small class="text-muted">Ano</small>
                        </div>
                        <div class="col-3 border-end">
                            <i class="bi bi-fuel-pump fs-3 text-primary"></i>
                            <p class="mb-0 fw-bold"><?php echo $carro['combustivel']; ?></p>
                            <small class="text-muted">Combustível</small>
                        </div>
                        <div class="col-3 border-end">
                            <i class="bi bi-speedometer2 fs-3 text-primary"></i>
                            <p class="mb-0 fw-bold"><?php echo number_format($carro['quilometragem'], 0, ',', ' '); ?></p>
                            <small class="text-muted">Km</small>
                        </div>
                        <div class="col-3">
                            <i class="bi bi-gear fs-3 text-primary"></i>
                            <p class="mb-0 fw-bold">Manual</p> <small class="text-muted">Caixa</small>
                        </div>
                    </div>

                    <h5 class="mb-3">Sobre esta viatura</h5>
                    <p class="text-muted">
                        Viatura nacional em excelente estado. Revisões todas na marca. 
                        Inclui garantia de 18 meses. Aceitamos retomas. 
                        (Este texto é um exemplo, podes adicionar um campo 'descricao' na base de dados depois!)
                    </p>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            
            <div class="card shadow mb-4">
                <div class="card-body">
                    <h6 class="text-muted text-uppercase">Preço de Venda</h6>
                    <h2 class="text-success fw-bold mb-3"><?php echo number_format($carro['preco'], 0, ',', '.'); ?> €</h2>
                    <p class="small text-muted mb-0">IVA incluído à taxa legal em vigor.</p>
                </div>
            </div>

            <div class="card shadow mb-4 bg-light border-primary">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-calculator"></i> Simular Financiamento</h5>
                </div>
                <div class="card-body">
                    <form id="simuladorForm">
                        <div class="mb-3">
                            <label class="form-label small">Valor do Carro</label>
                            <input type="number" id="precoCarro" class="form-control" value="<?php echo $carro['preco']; ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">Entrada Inicial (€)</label>
                            <input type="number" id="entradaInicial" class="form-control" value="0" min="0">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">Prazo (Meses)</label>
                            <select id="prazoMeses" class="form-select">
                                <option value="120">120 Meses</option>
                                <option value="96">96 Meses</option>
                                <option value="84">84 Meses</option>
                                <option value="72">72 Meses</option>
                                <option value="60">60 Meses</option>
                                <option value="48">48 Meses</option>
                            </select>
                        </div>
                        <hr>
                        <div class="text-center">
                            <small>Mensalidade Estimada:</small>
                            <h2 class="text-primary fw-bold" id="resultadoMensal">--- €</h2>
                            <small class="text-muted text-small-custom">Taxa exemplo de 8% TAN. Não dispensa consulta bancária.</small>
                        </div>
                    </form>
                </div>
            </div>

            <div class="d-grid gap-2">
                
                <button 
                    class="btn btn-outline-danger btn-lg favorito-btn mb-2" 
                    id="favorito-detalhe-<?php echo $carro['id']; ?>"
                    data-id="<?php echo $carro['id']; ?>"
                    data-marca="<?php echo htmlspecialchars($carro['marca']); ?>"
                    data-modelo="<?php echo htmlspecialchars($carro['modelo']); ?>"
                    data-versao="<?php echo htmlspecialchars($carro['versao']); ?>"
                    data-preco="<?php echo $carro['preco']; ?>"
                    data-foto="<?php echo htmlspecialchars($imagem); ?>"
                    onclick="handleFavorito(this)"
                >
                    <i class="bi bi-heart"></i> <span id="favorito-text-<?php echo $carro['id']; ?>">Adicionar aos Favoritos</span>
                </button>
                
                <?php if($carro['estado'] == 'Disponível'): ?>

                    <?php 
                        $texto_whatsapp = "Olá! Estou a ver no site o " . $carro['marca'] . " " . $carro['modelo'] . " (" . $carro['versao'] . "). Ainda está disponível?";
                        $texto_codificado = urlencode($texto_whatsapp);
                        $link_whatsapp = "https://wa.me/351968103232?text=" . $texto_codificado;
                    ?>
                    
                    <a href="<?php echo $link_whatsapp; ?>" class="btn btn-success btn-lg" target="_blank">
                        <i class="bi bi-whatsapp"></i> Contactar no WhatsApp
                    </a>
                    
                    <a href="checkout.php?id=<?php echo $carro['id']; ?>" class="btn btn-danger btn-lg">
                        <i class="bi bi-phone"></i> Comprar (MB WAY)
                    </a>

                <?php else: ?>
                    <button class="btn btn-secondary btn-lg disabled">
                        🚫 Indisponível / Vendido
                    </button>
                <?php endif; ?>

                <?php if(isset($_SESSION['logado'])): ?>
                    <hr>
                    <a href="admin/editar.php?id=<?php echo $carro['id']; ?>" class="btn btn-warning">
                        <i class="bi bi-pencil-square"></i> Editar Viatura
                    </a>
                    <a href="admin/eliminar.php?id=<?php echo $carro['id']; ?>" class="btn btn-outline-danger" onclick="return confirm('Tens a certeza?');">
                        <i class="bi bi-trash"></i> Eliminar
                    </a>
                <?php endif; ?>

            </div>

        </div>
    </div>
</div>

<script>
    // Pegar nos elementos do HTML
    const inputPreco = document.getElementById('precoCarro');
    const inputEntrada = document.getElementById('entradaInicial');
    const inputPrazo = document.getElementById('prazoMeses');
    const outputResultado = document.getElementById('resultadoMensal');

    // Função que faz a conta
    function calcularPrestacao() {
        let preco = parseFloat(inputPreco.value);
        let entrada = parseFloat(inputEntrada.value) || 0;
        let meses = parseInt(inputPrazo.value);
        let taxaJuro = 0.08; // 8% de Juro Anual (Exemplo)

        let montanteFinanciar = preco - entrada;
        
        if (montanteFinanciar <= 0) {
            outputResultado.innerText = "0,00 €";
            return;
        }

        // Fórmula Financeira (Sistema Francês / Price)
        let taxaMensal = taxaJuro / 12;
        let mensalidade = montanteFinanciar * (taxaMensal * Math.pow(1 + taxaMensal, meses)) / (Math.pow(1 + taxaMensal, meses) - 1);

        outputResultado.innerText = mensalidade.toFixed(2).replace('.', ',') + " €";
    }

    // Calcular logo ao abrir a página
    calcularPrestacao();

    // Recalcular sempre que o utilizador mudar a entrada ou o prazo
    inputEntrada.addEventListener('input', calcularPrestacao);
    inputPrazo.addEventListener('change', calcularPrestacao);
</script>

<script>
function handleFavorito(button) {
    const id = parseInt(button.getAttribute('data-id'));
    const marca = button.getAttribute('data-marca');
    const modelo = button.getAttribute('data-modelo');
    const versao = button.getAttribute('data-versao');
    const preco = parseFloat(button.getAttribute('data-preco'));
    const foto = button.getAttribute('data-foto');
    
    const adicionado = toggleFavorito(id, marca, modelo, versao, preco, foto);
    updateFavoritoButton(button.id, id);
    
    // Atualizar texto do botão
    const textoElement = document.getElementById('favorito-text-' + id);
    if (textoElement) {
        textoElement.textContent = adicionado ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos';
    }
}
</script>

<?php include 'includes/footer.php'; ?>