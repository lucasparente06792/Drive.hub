<?php 
include 'config/db.php';
include 'includes/header.php'; 

// Buscar dados do carro vendido para mostrar no comprovativo
$id = $_GET['id'];
$sql = "SELECT * FROM veiculos WHERE id = $id";
$result = $conn->query($sql);
$carro = $result->fetch_assoc();
?>

<div class="container mt-5 mb-5">
    <div class="text-center mb-5">
        <div class="mb-3">
            <i class="bi bi-check-circle-fill text-success success-icon"></i>
        </div>
        <h1 class="text-success fw-bold">Pagamento Confirmado!</h1>
        <p class="lead">Obrigado pela sua compra. O seu novo carro está à sua espera.</p>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white p-3">
                    <i class="bi bi-envelope"></i> <strong>Email enviado para:</strong> <?php echo $carro['comprador_email']; ?>
                </div>
                <div class="card-body p-5 bg-light">
                    
                    <h4 class="mb-3">Olá! Parabéns pelo seu novo <?php echo $carro['marca']; ?>.</h4>
                    <p>Confirmamos a receção do pagamento de <strong><?php echo number_format($carro['preco'], 2, ',', '.'); ?> €</strong>.</p>
                    
                    <div class="alert alert-info border-info">
                        <strong><i class="bi bi-geo-alt-fill"></i> Onde levantar o seu carro:</strong><br>
                        O seu veículo já se encontra preparado para entrega na nossa sede.
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>📍 Morada de Levantamento:</h5>
                            <p class="mb-1"><strong>Drive Hub - Stand Premium</strong></p>
                            <p class="mb-1">Zona Industrial do Neiva</p>
                            <p class="mb-1">4900-000 Viana do Castelo</p>
                            <p class="text-muted">Horário: 09:00 - 19:00</p>
                        </div>
                        <div class="col-md-6">
                            <div class="ratio ratio-16x9 border rounded">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d47195.39923838031!2d-8.8188175!3d41.69323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd25b62b1df6f1ad%3A0x6295781615598144!2sViana%20do%20Castelo!5e0!3m2!1spt-PT!2spt!4v1700000000000!5m2!1spt-PT!2spt" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>

                    <hr>
                    <p class="small text-muted text-center">
                        Este é um comprovativo automático. Por favor apresente este email ou o seu documento de identificação ao chegar ao stand.
                    </p>

                </div>
            </div>

            <div class="text-center mt-4">
                <a href="index.php" class="btn btn-outline-primary">Voltar à Página Inicial</a>
            </div>

        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>