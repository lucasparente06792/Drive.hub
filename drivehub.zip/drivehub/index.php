 <?php

include 'config/db.php';

include 'includes/header.php';



// Lógica do Dashboard (Cálculos para o Admin)

$total_carros = 0; $valor_stock = 0; $total_vendidos = 0;

if(isset($_SESSION['logado'])) {

    $res = $conn->query("SELECT COUNT(*) as t FROM veiculos"); $total_carros = $res->fetch_assoc()['t'];

    $res = $conn->query("SELECT SUM(preco) as v FROM veiculos WHERE estado = 'Disponível'"); $valor_stock = $res->fetch_assoc()['v'];

    $res = $conn->query("SELECT COUNT(*) as t FROM veiculos WHERE estado = 'Vendido'"); $total_vendidos = $res->fetch_assoc()['t'];

}

?>



<?php

$sql_destaque = "SELECT * FROM veiculos WHERE destaque = 1 AND estado = 'Disponível'";

$res_destaque = $conn->query($sql_destaque);



if ($res_destaque->num_rows > 0):

?>

            <div id="carouselDestaques" class="carousel slide mb-5" data-bs-ride="carousel" data-bs-interval="3000">

            <div class="carousel-indicators">

            <?php

            $i = 0;

            while($i < $res_destaque->num_rows) {

                echo '<button type="button" data-bs-target="#carouselDestaques" data-bs-slide-to="'.$i.'" class="'.($i==0?'active':'').'"></button>';

                $i++;

            }

            $res_destaque->data_seek(0); // Voltar ao início dos resultados

            ?>

        </div>

       

        <div class="carousel-inner">

            <?php

            $first = true;

            while($row = $res_destaque->fetch_assoc()):

                $imagem = !empty($row["foto_capa"]) ? $row["foto_capa"] : "https://placehold.co/1200x500?text=Destaque";

            ?>

                <div class="carousel-item <?php echo $first ? 'active' : ''; ?>">

                    <div class="carousel-item-container">

                        <img src="<?php echo $imagem; ?>" class="d-block w-100 carousel-item-image" alt="Destaque">

                    </div>

                    <div class="carousel-caption d-none d-md-block">

                        <h2 class="display-4 fw-bold"><?php echo $row['marca'] . ' ' . $row['modelo']; ?></h2>

                        <p class="fs-4"><?php echo $row['versao']; ?> | <?php echo $row['ano']; ?></p>

                        <a href="detalhes.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-lg fw-bold mt-2">

                            Ver Oferta - <?php echo number_format($row['preco'], 0, ',', '.'); ?> €

                        </a>

                    </div>

                </div>

            <?php

                $first = false;

            endwhile;

            ?>

        </div>

       

        <button class="carousel-control-prev" type="button" data-bs-target="#carouselDestaques" data-bs-slide="prev">

            <span class="carousel-control-prev-icon" aria-hidden="true"></span>

            <span class="visually-hidden">Anterior</span>

        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#carouselDestaques" data-bs-slide="next">

            <span class="carousel-control-next-icon" aria-hidden="true"></span>

            <span class="visually-hidden">Seguinte</span>

        </button>

    </div>



<?php else: ?>

    <div class="hero-banner text-center">

        <h1 class="display-4 fw-bold">Encontre o Carro dos seus Sonhos</h1>

        <p class="lead">Qualidade, Confiança e os Melhores Preços do Mercado.</p>

        <a href="#stock" class="btn btn-primary btn-lg mt-3">Ver Stock Disponível</a>

    </div>

<?php endif; ?>



<div class="container" id="stock">

    <div class="card p-4 mb-4 shadow-sm search-card">

    <form action="index.php" method="GET" class="row g-3">

        <h4 class="mb-0">Filtrar Preferências</h4>
        <div class="row">
            
            <div class="col-md-6 mb-3">

                <label class="form-label small fw-bold">Marca</label>
                <select name="busca" id="select-marca" class="form-select" onchange="fetchModelos(this.value)">
                    <option value="">Marca</option>

                    <?php
                    // Consulta para contar carros por marca
                        $sql_marcas = "SELECT marca, COUNT(*) as total FROM veiculos GROUP BY marca ORDER BY total DESC";
                        $res_marcas = $conn->query($sql_marcas);
                            while($m = $res_marcas->fetch_assoc()):
                                $selected = (isset($_GET['busca']) && $_GET['busca'] == $m['marca']) ? 'selected' : '';
                    ?>
                                <option value="<?php echo $m['marca']; ?>" <?php echo $selected; ?>>
                                    <?php echo $m['marca']; ?> (<?php echo $m['total']; ?>)
                                </option>
                    <?php endwhile; ?>
                </select>
            </div> 

            <div class="col-md-6 mb-3">
                <label class="form-label small fw-bold">Modelo</label>
                <select name="modelo" id="select-modelo" class="form-select" disabled>
                    <option value="">Selecione uma marca primeiro</option>
                </select>
            </div>

        </div>

        <div class="row">

            <div class="col-md-4 mb-3">

                <label class="form-label small fw-bold">Combustível</label>
                <select name="combustivel" id="select-combustivel" class="form-select">
                    <option value="">Combustiveis</option>
                    <?php
                        $sql_comb = "SELECT combustivel, COUNT(*) as total FROM veiculos GROUP BY combustivel ORDER BY combustivel ASC";
                        $res_comb = $conn->query($sql_comb);
                            while($c = $res_comb->fetch_assoc()):
                                if(empty($c['combustivel'])) continue; // Ignora se estiver vazio
                                $selected = (isset($_GET['combustivel']) && $_GET['combustivel'] == $c['combustivel']) ? 'selected' : '';
                                echo "<option value='{$c['combustivel']}' $selected>{$c['combustivel']} ({$c['total']})</option>";
                            endwhile;
                            ?>
                </select>

            </div>

            <div class="col-md-4 mb-3">

                <label class="form-label small fw-bold">Ano</label>
                <select name="ano" id="select-ano" class="form-select">
                    <option value="">Ano</option>
                    <?php
                        $sql_anos = "SELECT ano, COUNT(*) as total FROM veiculos GROUP BY ano ORDER BY ano DESC";
                        $res_anos = $conn->query($sql_anos);
                            while($a = $res_anos->fetch_assoc()):
                                $selected = (isset($_GET['ano']) && $_GET['ano'] == $a['ano']) ? 'selected' : '';
                                echo "<option value='{$a['ano']}' $selected>{$a['ano']} ({$a['total']})</option>";
                            endwhile;
                    ?>
                </select>

            </div>

            <div class="col-md-4 mb-3">
                <label class="form-label small fw-bold">Preço até</label>
                    <select name="preco_max" class="form-select">
                        <option value="">Qualquer preço</option>
                        <option value="5000" <?php if(isset($_GET['preco_max']) && $_GET['preco_max'] == '5000') echo 'selected'; ?>>5.000 EUR</option>
                        <option value="10000" <?php if(isset($_GET['preco_max']) && $_GET['preco_max'] == '10000') echo 'selected'; ?>>10.000 EUR</option>
                        <option value="20000" <?php if(isset($_GET['preco_max']) && $_GET['preco_max'] == '20000') echo 'selected'; ?>>20.000 EUR</option>
                        <option value="50000" <?php if(isset($_GET['preco_max']) && $_GET['preco_max'] == '50000') echo 'selected'; ?>>50.000 EUR</option>
                    </select>
            </div>
        </div>
                                
            <div class="col-md-4 mb-3 d-flex align-items-end gap-2">
                <button class="btn btn-primary w-50" type="submit">
                    <i class="bi bi-search"></i> Filtrar
                </button>

                <?php if (!empty($_GET['busca']) || !empty($_GET['ano']) || !empty($_GET['modelo']) || !empty($_GET['preco_max']) || !empty($_GET['combustivel'])): ?>
                    <a href="index.php#stock" class="btn btn-outline-danger w-50" title="Limpar tudo">
                        Limpar Filtros
                    </a>
                <?php endif; ?>
            </div>

    </form>

    </div>



    <?php if(isset($_SESSION['logado'])): ?>

    <div class="row mb-5">

        <div class="col-md-4"><div class="card bg-primary text-white p-3 text-center shadow"><h3><?php echo $total_carros; ?></h3><small>Total Carros</small></div></div>

        <div class="col-md-4"><div class="card bg-success text-white p-3 text-center shadow"><h3><?php echo number_format($valor_stock, 0,',','.'); ?> €</h3><small>Valor Stock</small></div></div>

        <div class="col-md-4"><div class="card bg-danger text-white p-3 text-center shadow"><h3><?php echo $total_vendidos; ?></h3><small>Vendidos</small></div></div>

    </div>

    <?php endif; ?>



    <div class="row">

        <?php

        $sql = "SELECT * FROM veiculos WHERE 1=1";


        // Filtro de Marca
        if(isset($_GET['busca']) && !empty($_GET['busca'])) {

            $termo = $conn->real_escape_string($_GET['busca']);

            $sql .= " AND (marca LIKE '%$termo%' OR modelo LIKE '%$termo%')";

        }

        // Filtro de Modelo
        if(!empty($_GET['modelo'])) {

            $modelo = $conn->real_escape_string($_GET['modelo']);

            $sql .= " AND modelo = '$modelo'";
        }

        // Filtro do Ano
        if(isset($_GET['ano']) && !empty($_GET['ano'])) {

            $ano = $conn->real_escape_string($_GET['ano']);

            $sql .= " AND ano = '$ano'";
        }

        // Filtro do Combustivel
        if(isset($_GET['combustivel']) && !empty($_GET['combustivel'])) {

            $comb = $conn->real_escape_string($_GET['combustivel']);

            $sql .= " AND combustivel = '$comb'";
        }

        // Filtro do Preço
        if(isset($_GET['preco_max']) && !empty($_GET['preco_max'])) {

            $p_max = (float)$_GET['preco_max'];

            $sql .= " AND preco <= $p_max";
        }



        $sql .= " ORDER BY estado ASC, id DESC"; // Ordenar

        $result = $conn->query($sql);



        if ($result && $result->num_rows > 0) {

            while($row = $result->fetch_assoc()) {

                $badgeColor = ($row["estado"] == 'Vendido') ? 'bg-danger' : (($row["estado"] == 'Reservado') ? 'bg-warning text-dark' : 'bg-success');

                $imagem = !empty($row["foto_capa"]) ? $row["foto_capa"] : "https://placehold.co/600x400?text=Sem+Foto";

               

                // Estrela se for destaque

                $estrela = ($row['destaque'] == 1) ? '<span class="badge bg-warning text-dark position-absolute top-0 start-0 m-2"><i class="bi bi-star-fill"></i> Top</span>' : '';

        ?>

                <div class="col-md-4 mb-4">

                    <div class="card shadow-sm h-100 hover-effect">

                        <?php echo $estrela; ?>

                        <div class="position-absolute top-0 end-0 m-2 badge <?php echo $badgeColor; ?>"><?php echo $row["estado"]; ?></div>

                        <img src="<?php echo $imagem; ?>" class="card-img-top" alt="Carro">

                        <div class="card-body d-flex flex-column">

                            <h5 class="card-title"><?php echo $row["marca"] . " " . $row["modelo"]; ?></h5>

                            <h6 class="text-muted"><?php echo $row["versao"]; ?></h6>

                            <ul class="list-unstyled mt-3 mb-3">

                                <li><i class="bi bi-calendar"></i> <?php echo $row["ano"]; ?> | <i class="bi bi-fuel-pump"></i> <?php echo $row["combustivel"]; ?></li>

                            </ul>

                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="fs-4 fw-bold text-primary"><?php echo number_format($row["preco"], 0, ',', '.'); ?> €</span>
                                    <button 
                                        class="btn btn-outline-danger btn-sm favorito-btn" 
                                        id="favorito-<?php echo $row['id']; ?>"
                                        data-id="<?php echo $row['id']; ?>"
                                        data-marca="<?php echo htmlspecialchars($row['marca']); ?>"
                                        data-modelo="<?php echo htmlspecialchars($row['modelo']); ?>"
                                        data-versao="<?php echo htmlspecialchars($row['versao']); ?>"
                                        data-preco="<?php echo $row['preco']; ?>"
                                        data-foto="<?php echo htmlspecialchars($imagem); ?>"
                                        onclick="handleFavorito(this)"
                                    >
                                        <i class="bi bi-heart"></i>
                                    </button>
                                </div>
                                <a href="detalhes.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary btn-sm w-100">Ver Detalhes</a>
                            </div>

                        </div>

                    </div>

                </div>

        <?php

            }

        } else {

            echo "<div class='col-12 text-center py-5'><p class='alert alert-warning'>Nenhum carro encontrado.</p></div>";

        }

        ?>

    </div>

</div>



<script>
function handleFavorito(button) {
    const id = parseInt(button.getAttribute('data-id'));
    const marca = button.getAttribute('data-marca');
    const modelo = button.getAttribute('data-modelo');
    const versao = button.getAttribute('data-versao');
    const preco = parseFloat(button.getAttribute('data-preco'));
    const foto = button.getAttribute('data-foto');
    
    const adicionado = toggleFavorito(id, marca, modelo, versao, preco, foto);
    updateFavoritoButton(button.id, id);
    
    // Feedback visual
    if (adicionado) {
        button.classList.add('animate__animated', 'animate__pulse');
        setTimeout(() => button.classList.remove('animate__animated', 'animate__pulse'), 1000);
    }
}
</script>


<script>
function atualizarFiltros(origem) {
    const marca = document.getElementById('select-marca').value;
    const modelo = document.getElementById('select-modelo').value;

    const urlBase = `get_modelos.php?marca=${encodeURIComponent(marca)}&modelo=${encodeURIComponent(modelo)}`;

    // 1. Atualizar Modelos (SÓ se a mudança veio da MARCA)
    if (origem === 'marca') {
        fetch(urlBase + '&tipo=modelo')
            .then(r => r.text())
            .then(html => {
                const selMod = document.getElementById('select-modelo');
                if(marca) {
                    selMod.innerHTML = html;
                    selMod.disabled = false;
                } else {
                    selMod.disabled = true;
                    selMod.innerHTML = '<option value="">Selecione uma marca primeiro</option>';
                }
            });
    }

    // 2. Atualizar Anos e Combustíveis (Sempre atualizam)
    fetch(urlBase + '&tipo=ano')
        .then(r => r.text())
        .then(html => document.getElementById('select-ano').innerHTML = html);

    fetch(urlBase + '&tipo=combustivel')
        .then(r => r.text())
        .then(html => document.getElementById('select-combustivel').innerHTML = html);
}

// Eventos corrigidos
document.getElementById('select-marca').addEventListener('change', function() {
    // Se mudou a marca, limpamos o modelo antigo e avisamos o script que a origem foi a marca
    document.getElementById('select-modelo').value = "";
    atualizarFiltros('marca');
});

document.getElementById('select-modelo').addEventListener('change', function() {
    // Se mudou o modelo, avisamos que a origem foi o modelo (para não dar "reset" na lista)
    atualizarFiltros('modelo');
});
</script>

<?php include 'includes/footer.php'; ?>