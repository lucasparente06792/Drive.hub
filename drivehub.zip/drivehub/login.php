<?php
session_start(); // Iniciar a gestão de sessões

// Se já estiver logado, manda para o index
if(isset($_SESSION['logado']) && $_SESSION['logado'] === true){
    header("location: index.php");
    exit;
}

$erro = "";

// Se alguém clicou no botão "Entrar"
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $utilizador = $_POST['user'];
    $senha = $_POST['pass'];

    // DEFINIR AQUI O TEU LOGIN E SENHA
    if($utilizador == "admin" && $senha == "1234") {
        $_SESSION['logado'] = true; // Cria o "cartão de acesso"
        header("location: index.php"); // Manda para a página principal
        exit;
    } else {
        $erro = "Login incorreto. Tenta outra vez.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Login - Stand Auto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page-body">
    <div class="card shadow p-4 login-card">
        <h3 class="text-center mb-4">Área Reservada</h3>
        
        <?php if($erro != "") echo "<div class='alert alert-danger'>$erro</div>"; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Utilizador</label>
                <input type="text" name="user" class="form-control" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label">Palavra-passe</label>
                <input type="password" name="pass" class="form-control" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Entrar</button>
            </div>
        </form>
        <div class="text-center mt-3">
            <a href="index.php" class="text-decoration-none">Voltar ao Site</a>
        </div>
    </div>
</body>
</html>