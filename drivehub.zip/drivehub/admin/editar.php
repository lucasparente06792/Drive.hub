<?php 
include '../config/db.php'; 
include '../includes/header.php'; 

// Segurança: Se não for admin, manda embora
if(!isset($_SESSION['logado'])) {
        echo "<script>window.location.href='../login.php';</script>";
    exit;
}

if (!isset($_GET['id'])) {
        echo "<script>window.location.href='../index.php';</script>";
    exit;
}

$id = $_GET['id'];

// 2. Processar a atualização
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $versao = $_POST['versao'];
    $ano = $_POST['ano'];
    $combustivel = $_POST['combustivel'];
    $km = $_POST['quilometragem'];
    $matricula = $_POST['matricula'];
    $cilindrada = $_POST['cilindrada'];
    $potencia = $_POST['potencia'];
    $preco = $_POST['preco'];
    $estado = $_POST['estado'];
    $destaque = isset($_POST['destaque']) ? 1 : 0;
    
    // Lógica da Foto: Se carregarem uma nova, usamos a nova. Se não, mantemos a antiga.
    $foto_final = $_POST['foto_atual']; // Começamos por assumir que a foto é a antiga

    if(isset($_FILES['foto_upload']) && $_FILES['foto_upload']['size'] > 0) {
        $diretorio = "../uploads/";
        $nome_ficheiro = $diretorio . time() . "_" . basename($_FILES["foto_upload"]["name"]);
        if (move_uploaded_file($_FILES["foto_upload"]["tmp_name"], $nome_ficheiro)) {
            $foto_final = $nome_ficheiro;
        }
    }

    $sql = "UPDATE veiculos SET 
            marca='$marca', modelo='$modelo', versao='$versao', 
            ano='$ano', combustivel='$combustivel', quilometragem='$km',
            matricula='$matricula', cilindrada='$cilindrada', potencia= '$potencia',
            preco='$preco', foto_capa='$foto_final',destaque='$destaque',estado='$estado' 
        
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        // Redireciona via Javascript para evitar erros de header
        echo "<script>window.location.href='../detalhes.php?id=$id';</script>"; 
        exit();
    } else {
        echo "<div class='alert alert-danger'>Erro ao atualizar: " . $conn->error . "</div>";
    }
}

// 3. Buscar dados atuais
$sql = "SELECT * FROM veiculos WHERE id = $id";
$result = $conn->query($sql);
$carro = $result->fetch_assoc();
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <a href="../detalhes.php?id=<?php echo $id; ?>" class="btn btn-outline-secondary mb-3">&larr; Cancelar</a>

            <div class="card shadow">
                <div class="card-header bg-warning text-dark">
                    <h4 class="mb-0">Editar Viatura</h4>
                </div>
                <div class="card-body">
                    
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="foto_atual" value="<?php echo $carro['foto_capa']; ?>">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Marca</label>
                                <input type="text" name="marca" class="form-control" value="<?php echo $carro['marca']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Modelo</label>
                                <input type="text" name="modelo" class="form-control" value="<?php echo $carro['modelo']; ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Versão</label>
                            <input type="text" name="versao" class="form-control" value="<?php echo $carro['versao']; ?>">
                        </div>

                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Ano</label>
                                <input type="number" name="ano" class="form-control" value="<?php echo $carro['ano']; ?>" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Combustível</label>
                                <select name="combustivel" class="form-select">
                                    <option <?php if($carro['combustivel'] == 'Diesel') echo 'selected'; ?>>Diesel</option>
                                    <option <?php if($carro['combustivel'] == 'Gasolina') echo 'selected'; ?>>Gasolina</option>
                                    <option <?php if($carro['combustivel'] == 'Elétrico') echo 'selected'; ?>>Elétrico</option>
                                    <option <?php if($carro['combustivel'] == 'Híbrido') echo 'selected'; ?>>Híbrido</option>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Estado</label>
                                <select name="estado" class="form-select">
                                    <option <?php if($carro['estado'] == 'Disponível') echo 'selected'; ?>>Disponível</option>
                                    <option <?php if($carro['estado'] == 'Reservado') echo 'selected'; ?>>Reservado</option>
                                    <option <?php if($carro['estado'] == 'Vendido') echo 'selected'; ?>>Vendido</option>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Quilómetros</label>
                                <input type="number" name="quilometragem" class="form-control" value="<?php echo $carro['quilometragem']; ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Matricula</label>
                            <input type="text" step="0.01" name="matricula" class="form-control" value="<?php echo $carro['matricula']; ?>" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">cilindrada</label>
                                <input type="text" name="cilindrada" class="form-control" value="<?php echo $carro['cilindrada']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Potência</label>
                                <input type="text" name="potencia" class="form-control" value="<?php echo $carro['potencia']; ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Preço (€)</label>
                            <input type="number" step="0.01" name="preco" class="form-control" value="<?php echo $carro['preco']; ?>" required>
                        </div>
                        <div class="mb-3 form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="destaque" value="1" id="destaqueCheck" <?php if($carro['destaque'] == 1) echo 'checked'; ?>>
                            <label class="form-check-label fw-bold" for="destaqueCheck">⭐ Colocar em Destaque (Slider Principal)</label>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alterar Foto (Opcional)</label>
                            <input type="file" name="foto_upload" class="form-control" accept="image/*">
                            <div class="form-text">Deixa vazio se quiseres manter a foto atual.</div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-warning btn-lg">💾 Guardar Alterações</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>