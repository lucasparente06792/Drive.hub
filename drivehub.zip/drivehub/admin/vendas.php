<?php 
include '../config/db.php'; 
include '../includes/header.php'; 

// Segurança: Se não for admin, manda embora
if(!isset($_SESSION['logado'])) {
    echo "<script>window.location.href='../login.php';</script>";
    exit;
}

// Buscar todos os veículos vendidos
$sql = "SELECT * FROM veiculos WHERE estado = 'Vendido' ORDER BY data_venda DESC, id DESC";
$result = $conn->query($sql);

$total_vendas = 0;
$valor_total_vendas = 0;
?>

<div class="container mt-5 mb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-cash-stack text-success"></i> Histórico de Vendas</h2>
        <a href="../index.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Voltar ao Stock
        </a>
    </div>

    <?php
    if ($result && $result->num_rows > 0) {
        // Calcular totais
        $result->data_seek(0); // Reset para recalcular
        while($row = $result->fetch_assoc()) {
            $total_vendas++;
            $valor_total_vendas += $row['preco'];
        }
        $result->data_seek(0); // Reset novamente para exibir
        
    ?>
        <!-- Estatísticas -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card bg-success text-white p-4 shadow">
                    <h3 class="mb-0"><?php echo $total_vendas; ?></h3>
                    <small>Total de Vendas</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-info text-white p-4 shadow">
                    <h3 class="mb-0"><?php echo number_format($valor_total_vendas, 0, ',', '.'); ?> €</h3>
                    <small>Valor Total das Vendas</small>
                </div>
            </div>
        </div>

        <!-- Tabela de Vendas -->
        <div class="card shadow">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="bi bi-list-ul"></i> Lista de Vendas</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Foto</th>
                                <th>Veículo</th>
                                <th>Versão</th>
                                <th>Ano</th>
                                <th>Preço</th>
                                <th>Data da Venda</th>
                                <th>Contacto</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): 
                                // Normalizar caminho da imagem para admin/vendas.php (precisa de ../uploads/)
                                $imagem_path = !empty($row["foto_capa"]) ? $row["foto_capa"] : "";
                                if (!empty($imagem_path) && (strpos($imagem_path, 'http') === 0 || strpos($imagem_path, 'https') === 0)) {
                                    // É uma URL externa, usar diretamente
                                    $imagem = $imagem_path;
                                } elseif (!empty($imagem_path) && strpos($imagem_path, '../uploads/') === 0) {
                                    // Já tem ../, manter assim
                                    $imagem = $imagem_path;
                                } elseif (!empty($imagem_path) && strpos($imagem_path, 'uploads/') === 0) {
                                    // Tem uploads/, adicionar ../
                                    $imagem = '../' . $imagem_path;
                                } else {
                                    $imagem = !empty($imagem_path) ? '../' . $imagem_path : "https://placehold.co/100x75?text=Sem+Foto";
                                }
                                $data_venda = !empty($row['data_venda']) ? date('d/m/Y H:i', strtotime($row['data_venda'])) : 'N/A';
                                $contacto = !empty($row['comprador_contacto']) ? $row['comprador_contacto'] : 'N/A';
                                $email = !empty($row['comprador_email']) ? $row['comprador_email'] : 'N/A';
                            ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo $imagem; ?>" alt="Foto" style="width: 100px; height: 75px; object-fit: cover; border-radius: 5px;">
                                    </td>
                                    <td>
                                        <strong><?php echo $row['marca'] . ' ' . $row['modelo']; ?></strong>
                                    </td>
                                    <td><?php echo $row['versao']; ?></td>
                                    <td><?php echo $row['ano']; ?></td>
                                    <td class="text-success fw-bold"><?php echo number_format($row['preco'], 0, ',', '.'); ?> €</td>
                                    <td><?php echo $data_venda; ?></td>
                                    <td><?php echo $contacto; ?></td>
                                    <td>
                                        <?php if($email != 'N/A'): ?>
                                            <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
                                        <?php else: ?>
                                            <?php echo $email; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php
    } else {
    ?>
        <div class="alert alert-info text-center py-5">
            <i class="bi bi-info-circle" style="font-size: 3rem;"></i>
            <h4 class="mt-3">Ainda não há vendas registadas</h4>
            <p class="text-muted">Quando um veículo for vendido, aparecerá aqui.</p>
        </div>
    <?php
    }
    ?>
</div>

<?php include '../includes/footer.php'; ?>
