<?php
session_start();
if(!isset($_SESSION['logado'])) {
        header("location: ../login.php");
    exit;
}
?>
<?php
include '../config/db.php';

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Comando SQL para apagar
    $sql = "DELETE FROM veiculos WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Se correu bem, redireciona para a página principal
        header("Location: ../index.php");
        exit();
    } else {
        echo "Erro ao apagar: " . $conn->error;
    }
} else {
    header("Location: index.php"); // Se não houver ID, volta para o início
}
?>