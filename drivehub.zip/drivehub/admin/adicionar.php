<?php
session_start();
if(!isset($_SESSION['logado'])) {
            header("location: ../login.php");
    exit;
}
?> <!--metodo de seguranca para destruir sessao ao tentar colocar o url no navegador web-->
<?php include '../config/db.php';
include '../includes/header.php'; ?>
<?php
$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $versao = $_POST['versao'];
    $ano = $_POST['ano'];
    $combustivel = $_POST['combustivel'];
    $km = $_POST['quilometragem'];
    $matricula = $_POST['matricula'];
    $cilindrada = $_POST['cilindrada'];
    $potencia = $_POST['potencia'];
    $preco = $_POST['preco'];
    
    // LÓGICA DE UPLOAD DE IMAGEM
    $diretorio = "../uploads/";
    // Criamos um nome único para a imagem não se misturar (ex: tempo_nome.jpg)
    $nome_ficheiro = $diretorio . time() . "_" . basename($_FILES["foto_upload"]["name"]);
    
    // Tentar mover o ficheiro da memória temporária para a pasta uploads
    if (move_uploaded_file($_FILES["foto_upload"]["tmp_name"], $nome_ficheiro)) {
        // Se o upload funcionou, guardamos o caminho na base de dados
        $foto_url = $nome_ficheiro; 
        
        $sql = "INSERT INTO veiculos (marca, modelo, versao, ano, combustivel, quilometragem, matricula, cilindrada, potencia, preco, foto_capa, estado) 
                VALUES ('$marca', '$modelo', '$versao', '$ano', '$combustivel', '$km','$matricula', '$cilindrada', '$potencia', '$preco', '$foto_url', 'Disponível')";

        if ($conn->query($sql) === TRUE) {
            $mensagem = "<div class='alert alert-success'>Viatura e Foto adicionadas com sucesso!</div>";
        } else {
            $mensagem = "<div class='alert alert-danger'>Erro SQL: " . $conn->error . "</div>";
        }
    } else {
        $mensagem = "<div class='alert alert-danger'>Erro ao carregar a imagem. Verifica se a pasta 'uploads' existe.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Viatura - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

    <div class="container mt-5 mb-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                
                <a href="../index.php" class="btn btn-outline-secondary mb-3">&larr; Voltar ao Stock</a>

                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Adicionar Nova Viatura</h4>
                    </div>
                    <div class="card-body">
                        
                        <?php echo $mensagem; ?>

                        <form method="POST" action="adicionar.php" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marca</label>
                                    <input type="text" name="marca" class="form-control" placeholder="Ex: Audi" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Modelo</label>
                                    <input type="text" name="modelo" class="form-control" placeholder="Ex: A4" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Versão</label>
                                <input type="text" name="versao" class="form-control" placeholder="Ex: 2.0 TDI S-Line">
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Ano</label>
                                    <input type="number" name="ano" class="form-control" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Combustível</label>
                                    <select name="combustivel" class="form-select">
                                        <option>Diesel</option>
                                        <option>Gasolina</option>
                                        <option>Elétrico</option>
                                        <option>Híbrido</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Quilómetros</label>
                                    <input type="number" name="quilometragem" class="form-control" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Matricula</label>
                                <input type="text" step="0.01" name="matricula" class="form-control" placeholder="Ex: XX-XX-XX" required>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Cilindrada</label>
                                    <input type="text" name="cilindrada" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Potência</label>
                                    <input type="text" name="potencia" class="form-control" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Preço (€)</label>
                                <input type="number" step="0.01" name="preco" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Foto do Carro</label>
                                <input type="file" name="foto_upload" class="form-control" accept="image/*" required>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success btn-lg">Adicionar Viatura</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>