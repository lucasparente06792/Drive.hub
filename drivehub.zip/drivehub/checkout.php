<?php 
include 'config/db.php'; 
include 'includes/header.php'; 

if(!isset($_GET['id'])) { header("Location: index.php"); exit; }

$id = $_GET['id'];
$sql = "SELECT * FROM veiculos WHERE id = $id AND estado = 'Disponível'";
$result = $conn->query($sql);

if($result->num_rows == 0) {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Este carro já não está disponível!</div></div>";
    include 'includes/footer.php'; exit;
}

$carro = $result->fetch_assoc();
?>

<div class="container mt-5">
    <h2 class="mb-4">Finalizar Compra</h2>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <?php $imagem = !empty($carro["foto_capa"]) ? $carro["foto_capa"] : "https://placehold.co/600x400"; ?>
                <img src="<?php echo $imagem; ?>" class="card-img-top" alt="Carro">
                <div class="card-body">
                    <h4><?php echo $carro['marca'] . ' ' . $carro['modelo']; ?></h4>
                    <p class="text-muted"><?php echo $carro['versao']; ?></p>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold">Total a Pagar:</span>
                        <span class="fs-4 text-success fw-bold"><?php echo number_format($carro['preco'], 2, ',', '.'); ?> €</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow p-4">
                <h4 class="text-danger mb-3"><i class="bi bi-shield-lock"></i> Dados de Pagamento</h4>
                <p>Preencha os seus dados para receber a fatura e a localização de levantamento.</p>
                
                <form action="actions/processar_pagamento.php" method="POST">
                    <input type="hidden" name="id_veiculo" value="<?php echo $carro['id']; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">O seu Email (Para envio do comprovativo)</label>
                        <input type="email" name="email" class="form-control form-control-lg" placeholder="exemplo@email.com" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nº de Telemóvel (MB WAY)</label>
                        <input type="text" name="telefone" class="form-control form-control-lg" placeholder="9xxxxxxxx" required pattern="[0-9]{9}" maxlength="9">
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-danger btn-lg">
                            Pagar <?php echo number_format($carro['preco'], 0, ',', '.'); ?> €
                        </button>
                    </div>
                    <small class="text-muted mt-2 d-block text-center"><i class="bi bi-lock"></i> Pagamento Seguro MB WAY</small>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>