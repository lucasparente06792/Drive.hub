<?php
include '../config/db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id_veiculo'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email']; // RECEBER O EMAIL
    $data = date('Y-m-d H:i:s');

    // 1. Verificar disponibilidade
    $check = $conn->query("SELECT estado FROM veiculos WHERE id = $id");
    $row = $check->fetch_assoc();

    if ($row['estado'] != 'Disponível') {
        die("Erro: Este carro acabou de ser vendido a outra pessoa!");
    }

    // 2. Processar a Venda e Gravar EMAIL
    $sql = "UPDATE veiculos SET 
            estado = 'Vendido', 
            destaque = 0, 
            comprador_contacto = '$telefone', 
            comprador_email = '$email', 
            data_venda = '$data' 
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Redirecionar para página de sucesso
        header("Location: ../sucesso.php?id=$id");
        exit();
    } else {
        echo "Erro ao processar: " . $conn->error;
    }
}
?>