<?php
session_start();
session_destroy(); // Destrói todas as sessões (rasga o cartão de acesso)
header("location: ../index.php"); // Manda de volta para o início
exit;
?>