<?php 
include 'config/db.php'; 
include 'includes/header.php'; 
?>

<div class="container mt-5 mb-5">
    <h2 class="mb-4"><i class="bi bi-heart-fill text-danger"></i> Meus Favoritos</h2>
    
    <div id="favoritos-container" class="row">
        <div class="col-12 text-center py-5">
            <p class="text-muted">A carregar os seus favoritos...</p>
        </div>
    </div>
</div>

<script>
function loadFavoritos() {
    const favoritos = getFavoritos();
    const container = document.getElementById('favoritos-container');
    
    if (favoritos.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="bi bi-heart text-muted" style="font-size: 4rem;"></i>
                <h4 class="mt-3 text-muted">Ainda não tens favoritos</h4>
                <p class="text-muted">Adiciona veículos aos favoritos clicando no ícone de coração!</p>
                <a href="index.php" class="btn btn-primary mt-3">Ver Stock</a>
            </div>
        `;
        return;
    }
    
    let html = '';
    
    favoritos.forEach(fav => {
        html += `
            <div class="col-md-4 mb-4" id="favorito-card-${fav.id}">
                <div class="card shadow-sm h-100 hover-effect">
                    <img src="${fav.foto}" class="card-img-top" alt="${fav.marca} ${fav.modelo}" style="height: 200px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">${fav.marca} ${fav.modelo}</h5>
                        <h6 class="text-muted">${fav.versao}</h6>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="fs-4 fw-bold text-primary">${formatarPreco(fav.preco)} €</span>
                                <button 
                                    class="btn btn-danger btn-sm" 
                                    onclick="removerFavoritoConfirm(${fav.id})"
                                >
                                    <i class="bi bi-heart-fill"></i>
                                </button>
                            </div>
                            <a href="detalhes.php?id=${fav.id}" class="btn btn-outline-primary btn-sm w-100">Ver Detalhes</a>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function removeFavorito(id) {
    const favoritos = getFavoritos();
    const index = favoritos.findIndex(fav => fav.id === id);
    
    if (index > -1) {
        favoritos.splice(index, 1);
        saveFavoritos(favoritos);
        
        // Remover card do DOM
        const card = document.getElementById('favorito-card-' + id);
        if (card) {
            card.remove();
        }
        
        // Recarregar se não houver mais favoritos
        if (favoritos.length === 0) {
            loadFavoritos();
        }
    }
}

function formatarPreco(preco) {
    return new Intl.NumberFormat('pt-PT').format(preco);
}

function removerFavoritoConfirm(id) {
    if (confirm('Tens a certeza que queres remover este veículo dos favoritos?')) {
        removeFavorito(id);
    }
}

// Carregar favoritos quando a página carregar
document.addEventListener('DOMContentLoaded', loadFavoritos);
</script>

<?php include 'includes/footer.php'; ?>
