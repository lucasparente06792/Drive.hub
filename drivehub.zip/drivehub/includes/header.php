<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$base_path = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false || strpos($_SERVER['PHP_SELF'], '/actions/') !== false) ? '../' : '';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drive Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/style.css"> 
    
    <script src="<?php echo $base_path; ?>assets/js/favoritos.js"></script>
</head>
<body class="bg-light">
    <div class="main-content">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top" style="box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo $base_path; ?>index.php">
                <img src="<?php echo $base_path; ?>uploads/logo1.png" alt="DriveHub" class="me-2">
                <span class="fw-bold text-white" style="letter-spacing: 1px;">DriveHub</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
               <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link px-3" href="<?php echo $base_path; ?>index.php">Stock</a></li>
                    <li class="nav-item"><a class="nav-link px-3" href="<?php echo $base_path; ?>favoritos.php"><i class="bi bi-heart-fill text-danger"></i> Favoritos</a></li>
                    
                    <?php if(isset($_SESSION['logado'])): ?>
                        <li class="nav-item"><a class="nav-link text-warning px-3" href="<?php echo $base_path; ?>admin/adicionar.php">Admin</a></li>
                        <li class="nav-item"><a class="nav-link text-info px-3" href="<?php echo $base_path; ?>admin/vendas.php">Vendas</a></li>
                        <li class="nav-item"><a class="nav-link text-danger px-3" href="<?php echo $base_path; ?>actions/logout.php"><i class="bi bi-box-arrow-right"></i></a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link px-3" href="<?php echo $base_path; ?>login.php">Login</a></li>
                    <?php endif; ?>

                    <li class="nav-item"><a class="btn btn-outline-light ms-2 btn-sm rounded-pill px-3" href="<?php echo $base_path; ?>contactos.php">Contactos</a></li>
                </ul>
            </div>
        </div>
    </nav>