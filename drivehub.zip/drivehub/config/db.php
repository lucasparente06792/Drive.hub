<?php
$servername = "127.0.0.1";
$username = "root";
$password = ""; // Se definiu uma senha no passo anterior, escreva-a aqui. Se não, deixe vazio.
$dbname = "stand_automoveis";

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar se houve erro
if ($conn->connect_error) {
    die("Falha na ligação: " . $conn->connect_error);
}

// Se não der erro, o script continua silenciosamente
// echo "Ligação feita com sucesso!"; // Pode descomentar para testar
?>