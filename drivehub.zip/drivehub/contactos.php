<?php include 'includes/header.php'; ?>

<div class="container mt-5">
    <h2 class="text-center mb-5">Fale Connosco</h2>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h4><i class="bi bi-geo-alt-fill text-primary"></i> Onde Estamos</h4>
                    <p>Zona Industrial do Neiva<br>4900-000 Viana do Castelo, Portugal</p>
                    
                    <h4 class="mt-4"><i class="bi bi-telephone-fill text-primary"></i> Telefone</h4>
                    <p>+351 222 000 000</p>
                    
                    <h4 class="mt-4"><i class="bi bi-envelope-fill text-primary"></i> Email</h4>
                    <p>drivehub@gmail.com</p>

                    <div class="mt-3 map-container">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d190604.68418147284!2d-8.809192!3d41.716242!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd25b7cef6e86a73%3A0xfe4d167e5dd21dfd!2sViana%20do%20Castelo!5e0!3m2!1spt-PT!2spt!4v1767979873501!5m2!1spt-PT!2spt" width="600" height="200" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <h4>Envie uma Mensagem</h4>
                    <form>
                        <div class="mb-3">
                            <label>Nome</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Mensagem</label>
                            <textarea class="form-control" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Enviar Pedido</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>