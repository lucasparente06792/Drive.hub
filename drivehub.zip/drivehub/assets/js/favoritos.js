// Sistema de Favoritos usando localStorage

// Função para obter favoritos do localStorage
function getFavoritos() {
    const favoritos = localStorage.getItem('favoritos');
    return favoritos ? JSON.parse(favoritos) : [];
}

// Função para guardar favoritos no localStorage
function saveFavoritos(favoritos) {
    localStorage.setItem('favoritos', JSON.stringify(favoritos));
}

// Função para adicionar ou remover favorito
function toggleFavorito(id, marca, modelo, versao, preco, foto) {
    let favoritos = getFavoritos();
    const index = favoritos.findIndex(fav => fav.id === id);
    
    if (index > -1) {
        // Remover se já está nos favoritos
        favoritos.splice(index, 1);
        saveFavoritos(favoritos);
        return false; // Retorna false se removeu
    } else {
        // Adicionar se não está nos favoritos
        favoritos.push({
            id: id,
            marca: marca,
            modelo: modelo,
            versao: versao,
            preco: preco,
            foto: foto
        });
        saveFavoritos(favoritos);
        return true; // Retorna true se adicionou
    }
}

// Função para verificar se um veículo está nos favoritos
function isFavorito(id) {
    const favoritos = getFavoritos();
    return favoritos.some(fav => fav.id === id);
}

// Função para atualizar o ícone do botão de favorito
function updateFavoritoButton(buttonId, id) {
    const button = document.getElementById(buttonId);
    if (button) {
        const icon = button.querySelector('i');
        if (isFavorito(id)) {
            button.classList.remove('btn-outline-danger');
            button.classList.add('btn-danger');
            if (icon) {
                icon.className = 'bi bi-heart-fill';
            }
        } else {
            button.classList.remove('btn-danger');
            button.classList.add('btn-outline-danger');
            if (icon) {
                icon.className = 'bi bi-heart';
            }
        }
    }
}

// Função para inicializar botões de favorito na página
function initFavoritos() {
    // Atualizar todos os botões com class "favorito-btn"
    document.querySelectorAll('.favorito-btn').forEach(button => {
        const id = parseInt(button.getAttribute('data-id'));
        if (id) {
            updateFavoritoButton(button.id || 'favorito-' + id, id);
        }
    });
}

// Inicializar quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFavoritos);
} else {
    initFavoritos();
}
